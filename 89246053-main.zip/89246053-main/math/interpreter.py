def expression(x, y, z):
    if y == "+":
        return x + z
    elif y == "-":
        return x - z
    elif y == "*":
        return x * z
    elif y == "/":
        if z != "0":
            return x / z
    else :
         return "Invalid Format"

def expression(x, y, z):
    if y == "+":
        return x + z
    elif y == "-":
        return x - z
    elif y == "*":
        return x * z
    elif y == "/":
        if z != 0:
            return x / z
        else:
            print("Error: Division by zero")
            return None
    else:
        return "Invalid Format"  # Return a message for invalid format

def main():
    prompt = input("What's the expression? ").strip()
    components = prompt.split()
    if len(components) != 3:
        print("Invalid Format")
        return

    try:
        x = int(components[0])
        y = components[1]
        z = int(components[2])

        if y == '/' and z == 0:  # Check for division by zero
            print("Error: Division by zero")
            return

        result = expression(x, y, z)
        if result is not None:
            print("Result: {:.1f}".format(result))
    except (ValueError, ZeroDivisionError):
        print("Invalid input. Please enter valid integers for 'x' and 'z'.")

if __name__ == "__main__":
    main()
