word = input().lower()
print(word)

