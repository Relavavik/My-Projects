Meal = {
    "Baja Taco": 4.25,
    "Burrito": 7.50,
    "Bowl": 8.50,
    "Nachos": 11.00,
    "Quesadilla": 8.50,
    "Super Burrito": 8.50,
    "Super Quesadilla": 9.50,
    "Taco": 3.00,
    "Tortilla Salad": 8.00
}

order = 0.00

try :
  while True:
    prompt = input("Item: ").title().strip()
    if prompt in Meal:
      order += Meal[prompt]
      print(f"${order:.2f}")
    elif prompt not in Meal:
      print("")
    else:
      break
except EOFError:
  pass
