def main():
    prompt = input("Give: ")
    if is_valid(prompt):
        print("Valid")
    else :
        print("Invalid")

def is_valid(s):
    return (
        star2let(s) and
        charlen(s) and
        val_char(s) and
        not_in_mid(s) and
        num_end(s) and
        nozero(s)

    )

# All vanity plates must start with at least two letters.
def charlen(s):
    return 2 <= len(s) <= 6

# “… vanity plates may contain a maximum of 6 characters (letters or numbers) and a minimum of 2 characters.”
def star2let(s):
    return s[:2].isalpha()


#Numbers cannot be used in the middle of a plate
def val_char(s):
    return s.isalnum()


def not_in_mid(s):
    for i in range(len(s)):
        if s[i].isdigit():
            if i != len(s) - 1 and not s[i:].isdigit():
                return False
            break
    return True

def num_end(s):
    for i in range(len(s)):
        if s[i].isdigit():
            return s[i:].isdigit()
    return True

def nozero(s):
    for i in range(len(s)):
        if s[i].isdigit():
            if s[i] == '0':
                return False
            break
    return True
main()
