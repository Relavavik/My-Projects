def main():

        fraction = input("How much is left")
        percentage = g_fuel_p(fraction)
        if percentage == "E":
            print("E")
        elif percentage == "F":
            print("F")
        else:
            print(f"{percentage}%")




def g_fuel_p(prompt):
    try :
        x, y = map(int, prompt.split("/"))
        percentage = (x / y) * 100
        if percentage <= 1 :
            return "E"
        elif percentage == 99 or 100:
            return "F"
        elif percentage > 100:
            return None
        else :
            return round(percentage)
    except ValueError :
        return
    except ZeroDivisionError:
        return
main()
