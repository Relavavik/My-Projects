x = input('What is the answer?').lower().strip()
match x:
    case "forty two" | "42" | "forty-two" :
        print("Yes")
    case _:
        print("No")
