fruits = {
    "Apple" : "130",
    "Avocado" : "50",
    "Kiwifruit" : "90",
    "Pear" : "100",
    "Sweet Cherries" : "100"
}

prompt = input("Item: ").title()
if prompt in fruits:
    print("Calories: ", fruits[prompt])
