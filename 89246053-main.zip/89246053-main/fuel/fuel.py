while True:
    try:
        prompt = input(": ")
        x,y = map(int, prompt.split("/"))
        if x <= y:
            z = (x / y) * 100
            if 1 < z < 99:
                print(round(z),"%", sep="")
                break
            elif z <= 1 :
                print("E")
                break
            elif 99 <= z <= 100:
                print("F")
                break
    except ( ValueError, ZeroDivisionError):
        pass
