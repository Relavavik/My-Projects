x = 50
accepted = {25,10,5}
while x > 0:
        s = int(input("Insert Coin:"))
        if s in accepted :
            x -= s
            if x > 0:
                print(f"Amount Due: {abs(x)}")
            else :
                print(f"Change Owed: {abs(x)}")
                break
        else:
             print(f"Amount Due: {abs(x)}")
             break


