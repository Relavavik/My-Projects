def my_prog(x):
    output = " "
    for i in x:
        if i.isupper() :
            output += "_" + i.lower()
        else :
            output += i
    return output.lstrip("_")

def main():
    x = input("camelCase")
    output = my_prog(x)
    print("Output", output)

if __name__ == "__main__":
    main()
