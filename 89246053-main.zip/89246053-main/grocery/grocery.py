def main():
    import sys
    from collections import defaultdict
    items = defaultdict(int)
    try :
        while True:
            item = input().strip().lower()
            if item:
                items[item] += 1

    except EOFError:
        pass

    asorted = sorted(items.keys())


    for item in asorted:
        print(f"{items[item]} {item.upper()}")
main()
