prompt = input().replace(" ","")
print(prompt)
