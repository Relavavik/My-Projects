def convert(time_str):
    hours, minutes = map(int, time_str.split(":"))
    return hours + minutes / 60

def main():
    time_input = input("Do you know what time it is?")
    hours = convert(time_input)

    if 7.0 <= hours <= 8.0:
        return "Breakfast Time"
    elif 12.0 <= hours <= 13.0:
        return "Lunch Time"
    elif 18.0 <= hours <= 19.0:
        return "Dinner Time"

if __name__ == "__main__":
    print(main())

