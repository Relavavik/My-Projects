from emoji import emojize
inp = input("Input: ")
print(emojize(inp, language ="alias"))
