def main():
    x = input("Tell: ").strip()
    if x.startswith("Hello"):
        print("$0", not "$20\n")
    elif x.startswith("H"):
        print("$20")
    else:
        print("$100")

main()
