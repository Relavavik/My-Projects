mon={
    "January": 1,
    "February": 2,
    "March": 3,
    "April": 4,
    "May": 5,
    "June": 6,
    "July": 7,
    "August": 8,
    "September": 9 ,
    "October": 10,
    "November": 11,
    "December": 12
}
try:
    while True:
        prompt = input("Date: ").strip()
        if "/" in prompt:
            x,y,z = prompt.split("/")
        else:
            x,y,z = prompt.split(" ")
            y = y.strip(",")

        if x in mon:
            if "," in prompt:
                x = mon[x]
                y = int(y.replace(",", " "))
                z = int(z)
                if x < 13 and y <32:
                    print(f"{z:04}-{x:02}-{y:02}")
                    break
        elif y in mon or z in mon :

            print("Error")
        else:
            x = int(x)
            y = int(y)
            z = int(z)
            if x < 13 and y <32:
                print(f"{z:04}-{x:02}-{y:02}")
                break

except {ValueError, EOFError}:
    pass
