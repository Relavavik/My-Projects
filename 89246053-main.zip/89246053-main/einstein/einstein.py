def main():
    x = int(input("m: "))
    print(x*90000000000000000)

main()


