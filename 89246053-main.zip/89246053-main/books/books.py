prompt = input().strip(" ")
books = list(map(prompt))
