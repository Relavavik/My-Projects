def main():
    prompt = input('string')
    done(prompt)


def done(x):
    vow = 'aeiou'
    result = ''.join([i for i in x if i.lower() not in vow])
    print(result)

main()
