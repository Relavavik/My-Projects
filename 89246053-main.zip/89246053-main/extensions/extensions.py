def main():
    x = input("File name:").lower().strip()
    if x.endswith(".gif"):
        return "image/gif"
    elif x.endswith(".pdf"):
        return "application/pdf"
    elif x.endswith(".jpg") or x.endswith("jpeg"):
        return "image/jpeg"
    elif x.endswith(".png"):
        return "image/png"
    elif x.endswith(".txt"):
        return "text/plain"
    elif x.endswith(".zip"):
        return "application/zip"
    else :
        return "application/octet-stream"
print(main())

