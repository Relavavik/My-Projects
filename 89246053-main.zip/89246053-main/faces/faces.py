def main():
    prompt=input()
    print(prompt)
    prompt = convert(prompt)
    print(prompt)

def convert(prompt):
    prompt =prompt.replace(":)","🙂")
    prompt =prompt.replace(":(","🙁")
    return prompt
main()














##
# prompt = input()
# words= prompt.split("  ")
# emoji = {
  #      ":)":"🙂",
   #     ":(":"🙁"}
# output = ""
# for word in words:
 #   output += emoji.get(word, word) + " "

# print(output)
##
